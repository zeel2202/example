import React from 'react'

function Sidebar() {
  return (
   <>
   <div className='bg-success' style={{height:"100vh"}}>
   <h2>Sidebar</h2>
   </div>
   </>
  )
}

export default Sidebar