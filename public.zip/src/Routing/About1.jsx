import React from 'react'

function About1() {
  return (
    <div>About1</div>
  )
}

export default About1