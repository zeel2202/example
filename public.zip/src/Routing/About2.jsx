import React from 'react'

function About2() {
  return (
    <div>About2</div>
  )
}

export default About2